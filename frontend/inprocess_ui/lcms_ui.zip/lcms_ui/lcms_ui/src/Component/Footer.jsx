import React from 'react'; 

const Footer = () => {
  return (
    <>
        <div className="text-center p-3" style={{ backgroundColor: '#353755',color: "#E0E4EE", position: "fixed",height: '40px', bottom: '0', width: '100%' }}>© 2020 Copyright
        </div>
    </>
  )
}

export default Footer;
