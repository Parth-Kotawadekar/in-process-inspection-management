import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import Service from '../Service/Service';
import './CSS/Global.css';

const CreateCertificate = () => {
    const [gauges, setGauges] = useState({
        gauge_name:"",
        gauge_sr_no:"",
        gauge_type:"",
        manufacture_id:"",
        make:"",
        size:"",
        range:""
    });
    const [datasheet, setDatasheet] = useState({
        datasheet_id:"",
        calibration_date:"",
        next_calibration_date:"",
        calibration_frequency:"",
        gaugeMaster: {
            gauge_id:""
        }

    });

    const { datasheet_id, gauge_id } = useParams();
    const navigate = useNavigate();
    
    useEffect(() => {
        const fetchData = async () => {
            try {
                // Fetch datasheet details
                const datasheetResponse = await Service.getDatasheetById(datasheet_id);
                const datasheetData = datasheetResponse.data;
                setDatasheet(datasheetData);
                console.log(datasheetData);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, [datasheet_id]);

    useEffect(() => {
        Service.getGaugeById(gauge_id).then((res)=> {
            setGauges(res.data);
            console.log(gauges);
        }).catch((error) => {
            console.error(error);
        })
    })

    const handleGaugeChange = (e) => {
        const { name, value } = e.target;
        setDatasheet({ ...datasheet, [name]: value });
    };

    const CertificateRegister = (e) => {
        e.preventDefault();
        Service.createDatasheet(datasheet)
            .then(() => {
                navigate("/datasheet");
            })
            .catch((error) => {
                console.error('Error creating datasheet:', error);
            });
    };

    const returnPage = () => {
        navigate('/datasheet');
    };

    return ( 
        <div className='container'>
            <div className='row'>
                <div className='col-md-6'>
                    <div className='card'>
                        <div className='card-header fs-3 text-center'>
                            <h2>Create Certificate</h2>
                        </div>
                        <div className='card-body'>
                            <form onSubmit={CertificateRegister}>
                                <div className='row'>
                                    {/* Gauge details on the left side */}
                                    <div className='col-md-6'>
                                        <div className='mb-3'>
                                            <label>Gauge Name:</label>
                                            <input
                                                type="text"
                                                name="gauge_id"
                                                className='form-control read-only-field'
                                                value={datasheet.gauge_id || ''}
                                                readOnly
                                            />
                                            <label>Gauge Name:</label>
                                            <input
                                                type="text"
                                                name="gauge_name"
                                                className='form-control read-only-field'
                                                value={gauges.gauge_name || ''}
                                                readOnly
                                            />
                                            <label>Gauge Sr No:</label>
                                            <input
                                                type="text"
                                                name="gauge_sr_no"
                                                className='form-control read-only-field'
                                                value={gauges.gauge_sr_no || ''}
                                                readOnly
                                            />
                                            <label>Gauge Type:</label>
                                            <input
                                                type="text"
                                                name="gauge_type"
                                                className='form-control read-only-field'
                                                value={gauges.gauge_type || ''}
                                                readOnly
                                            />
                                            <label>Manufacture Id:</label>
                                            <input
                                                type="text"
                                                name="manufacture_id"
                                                className='form-control read-only-field'
                                                value={gauges.manufacture_id || ''}
                                                readOnly
                                            />
                                            <label>Make:</label>
                                            <input
                                                type="text"
                                                name="make"
                                                className='form-control read-only-field'
                                                value={gauges.make || ''}
                                                readOnly
                                            />
                                            <label>Size:</label>
                                            <input
                                                type="text"
                                                name="size"
                                                className='form-control read-only-field'
                                                value={gauges.size || ''}
                                                readOnly
                                            />
                                            <label>Range:</label>
                                            <input
                                                type="text"
                                                name="gauge_range"
                                                className='form-control read-only-field'
                                                value={gauges.condition_description || ''}
                                                readOnly
                                            />
                                        </div>
                                    </div>
                                    {/* Datasheet details on the right side */}
                                    <div className='col-md-6'>
                                        <div className='mb-3'>
                                            <label>Calibration Date:</label>
                                            <input
                                                type="text"
                                                name="calibration_date"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.calibration_date || ''}
                                            />
                                            <label>Next Due:</label>
                                            <input
                                                type="text"
                                                name="next_calibration_date"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.next_calibration_date || ''}
                                            />
                                            <label className='check_mast mt-3'>Frequency:</label>
                                            <input
                                                type="text"
                                                name="calibration_frequency"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.calibration_frequency || ''}
                                            />
                                            <label>Frequency Type:</label>
                                            <input
                                                type='text'
                                                name="frequency_type"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.frequency_type || ''}
                                            />
                                            <label>Receipt Date:</label>
                                            <input
                                                type="text"
                                                name="date_of_reciept"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.date_of_reciept || ''}
                                            />
                                            <label>Ref Dc. No.:</label>
                                            <input
                                                type="text"
                                                name="ref_dc_no"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.ref_dc_no || ''}
                                            />
                                            <label>Issue Date:</label>
                                            <input
                                                type="text"
                                                name="issue_date"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.issue_date || ''}
                                            />
                                            <label>Identified by:</label>
                                            <input
                                                type="text"
                                                name="identification_marked_by"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.identification_marked_by || ''}
                                            />
                                            <label>Certificate no:</label>
                                            <input
                                                type="text"
                                                name="certificate_no"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.certificate_no || ''}
                                            />
                                            <label>Calibration Place:</label>
                                            <input
                                                type="text"
                                                name="calibration_place"
                                                className='form-control read-only-field'
                                                onChange={handleGaugeChange}
                                                value={datasheet.calibration_place || ''}
                                            />
                                        </div>
                                    </div>
                                </div>
                                <button
                                    className='btn btn-primary'
                                    type='submit'>Submit
                                </button>
                                <button
                                    className='btn btn-secondary mx-3'
                                    type='button'
                                    onClick={returnPage}>Close
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CreateCertificate;
