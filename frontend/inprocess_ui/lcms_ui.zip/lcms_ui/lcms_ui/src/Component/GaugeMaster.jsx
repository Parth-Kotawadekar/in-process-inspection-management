import React, { useState, useEffect } from 'react';
import Service from '../Service/Service';
import { Link } from 'react-router-dom';
import './CSS/Global.css'

const GaugeMaster = () => {
  const [gauges, setGauges] = useState([]);
  const [query, setQuery] = useState('');
  const [searchGaugeItems, setSearchGaugeItems] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10); // Number of items per page

  useEffect(() => {
    init();
  }, []);

  const init = () => {
    Service.getAllGauge()
      .then((res) => {
        setGauges(res.data);
        setSearchGaugeItems(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const deleteGauge = (gauge_id) => {
    Service.deleteGauge(gauge_id)
      .then(() => {
        console.log("Gauge Deleted Successfully");
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleSearch = (e) => {
    const getGauge = e.target.value.toLowerCase();
    setQuery(getGauge);

    if (getGauge.length > 0) {
      const searchGaugeResult = searchGaugeItems.filter((item) =>
        item.gauge_sr_no.toLowerCase().includes(getGauge)
      );
      setGauges(searchGaugeResult);
    } else {
      setGauges(searchGaugeItems);
    }
  };

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = gauges.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12'>
            <div className='card'>
              <h1>
                <div className='card-header fs-1 mt-5 text-center'>Gauge Details</div>
              </h1>
              <div className='card-body'>
                <div className="d-flex justify-content-between mb-3">
                  <Link to="/addGauge" className='btn mb-3 btn-primary'>Add New</Link>
                  <div className="searchbox">
                    <input 
                      type="text" 
                      placeholder='Search By Serial No.'
                      className='form-control'
                      value={query}
                      onChange={handleSearch}
                    />
                  </div>
                </div>
                <div className='table-responsive'>
                  <table className="table table-striped">
                    <thead className='table_header'>
                      <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Gauge Name</th>
                        <th scope="col">Sr. No</th>
                        <th scope="col">Gauge Type</th>
                        <th scope="col">Manufacturer Id</th>
                        <th scope="col">Size</th>
                        <th scope="col">Rangw</th>
                        <th scope="col">Make</th>
                        <th scope="col">Go-Were Limit</th>
                        <th scope="col">Instrument Type</th>
                        <th scope="col">Lower Size</th>
                        <th scope="col">Higher Size</th>
                        <th scope="col">Tolerance Type</th>
                        <th scope="col">Go Tolerance +</th>
                        <th scope="col">Go Tolerance -</th>
                        <th scope="col">NoGo Tolerance +</th>
                        <th scope="col">NoGo Tolerance -</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentItems.map((gauge, index) => (
                        <tr key={gauge.gauge_id}>
                          <td>{index + indexOfFirstItem + 1}</td>
                          <td>{gauge.gauge_name}</td>
                          <td>{gauge.gauge_sr_no}</td>
                          <td>{gauge.gauge_type}</td>
                          <td>{gauge.manufacture_id}</td>
                          <td>{gauge.size}</td>
                          <td>{gauge.gauge_range}</td>
                          <td>{gauge.make}</td>
                          <td>{gauge.go_were_limit}</td>
                          <td>{gauge.instrument_type}</td>
                          <td>{gauge.lower_size}</td>
                          <td>{gauge.higher_size}</td>
                          <td>{gauge.tolerance_type}</td>
                          <td>{gauge.go_tolerance_plus}</td>
                          <td>{gauge.go_tolerance_minus}</td>
                          <td>{gauge.nogo_tolerance_pus}</td>
                          <td>{gauge.nogo_tolerance_minus}</td>
                          <td className="d-flex align-items-center">
                            <Link to={'/updateGauge/' + gauge.gauge_id} className='btn btn-sm btn-primary'>Edit</Link>
                            <Link to={'/addDatasheet/' + gauge.gauge_id} className='btn btn-sm btn-dark ms-2'>Datasheet</Link>
                            <button onClick={() => deleteGauge(gauge.gauge_id)} className='btn btn-sm btn-danger ms-2'>Delete</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {/* Pagination */}
                <div className="pagination-wrapper">
        <ul className="pagination justify-content-center">
          {Array.from({ length: Math.ceil(gauges.length / itemsPerPage) }, (_, index) => (
            <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
              <button onClick={() => paginate(index + 1)} className="page-link">
                {index + 1}
              </button>
            </li>
          ))}
        </ul>
      </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GaugeMaster;
